<?php

class Application_Model_DbTable_RecoveryQueue extends Zend_Db_Table_Abstract
{

    protected $_name = 'recoveryQueue';


}

