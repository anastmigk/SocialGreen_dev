<?php

class Application_Model_DbTable_Ladder extends Zend_Db_Table_Abstract
{

    protected $_name = 'ladder';


}

