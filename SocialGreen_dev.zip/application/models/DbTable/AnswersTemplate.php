<?php

class Application_Model_DbTable_AnswersTemplate extends Zend_Db_Table_Abstract
{

    protected $_name = 'answers_template';


}

