<?php

class Application_Model_DbTable_Accounts extends Zend_Db_Table_Abstract
{

    protected $_name = 'accounts';


}

