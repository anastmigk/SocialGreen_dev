<?php

class Application_Model_DbTable_Answers extends Zend_Db_Table_Abstract
{

    protected $_name = 'answers';


}

