<?php

class Application_Model_DbTable_UserBadges extends Zend_Db_Table_Abstract
{

    protected $_name = 'user_badges';


}

