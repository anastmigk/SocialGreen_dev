<?php

class Application_Model_DbTable_Questions extends Zend_Db_Table_Abstract
{

    protected $_name = 'questions';


}

