Social Green Project
==========

Site for the first Social rewarding recycling system in the world!